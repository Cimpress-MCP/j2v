import datetime


def is_str_timestamp(potential_ts):
    """
    Checks if a string represents a timestamp
    :param potential_ts:
    :return: True only if string represents a timestamp
    """
    try:
        datetime.datetime.strptime(potential_ts, "%Y-%m-%dT%H:%M:%S.%fZ")
        return True
    except:
        return False


def is_non_empty_array_with_dicts(value):
    return is_non_empty_list(value) and is_dict(value[0])

def is_non_empty_array_with_primitives(value):
    return is_non_empty_list(value) and is_primitive(value[0])


def is_dict(value):
    return type(value) == dict


def is_non_empty_list(value):
    return type(value) == list and len(value) > 0


def is_primitive(value):
    """
    Checks if value if a python primitive
    :param value:
    :return:
    """
    return type(value) in (int, float, bool, str)
