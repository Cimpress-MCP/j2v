import json
import re
from collections import defaultdict

import j2v.str_templates.looker_templates as lt
from j2v.helpers import *


class Generator:
    def __init__(self):
        """
        Init empty lists and ops counter.
        """
        self.views_dimensions_expr = defaultdict(list)
        self.views_dimensions = defaultdict(list)
        self.explore_joins = list()
        self.ops = 0
        # setting for name construction, leave 1 or increment
        self.maximum_naming_levels = 1

    def collect_all_paths(self, current_dict, current_path="payload", current_view="base", root_view="base"):
        """
        Recursive. Explores the data in JSON and takes appropriate actions.
        :param current_dict: Currently processed dict
        :param current_path: Path from the root dict
        :param current_view: Currently processed view
        :param root_view:
        :return:
        """
        for key, value in current_dict.items():
            if is_primitive(value):
                self.add_dimension(current_path, current_view, key, value)
            elif is_dict(value):
                self.collect_all_paths(value, current_path + ":" + key, current_view, root_view)
            elif is_non_empty_list(value):
                sample_element = value[0]
                new_view_name = (current_view + "_" + key) if self.views_dimensions_expr[key] else key
                self.add_explore_join(new_view_name=new_view_name, current_view=current_view,
                                      key=key, current_path=current_path)

                if is_dict(sample_element):
                    self.collect_all_paths(current_dict=sample_element, current_path="VALUE",
                                           current_view=new_view_name,
                                           root_view=current_view)
                elif is_primitive(sample_element):
                    self.add_dimension("", new_view_name, "VALUE", sample_element)

    def add_explore_join(self, new_view_name, current_view, key, current_path):
        """

        :param join_path:
        :param new_view_name:
        :param current_view:
        :return:
        """
        join_path = current_view + (":" if current_view != "base" else ".") + current_path + ":" + key
        join_path = join_path.replace(":VALUE", ".VALUE")

        if current_view is "base":
            required_joins_line = ""
        else:
            required_joins_line = lt.req_joins_str_template.format(required_join=current_view)

        explore_join = lt.explore_join_str_template.format(alias=new_view_name, view=new_view_name,
                                                           exploded_structure_path=join_path,
                                                           required_joins_line=required_joins_line)

        self.explore_joins.append(explore_join)

    def add_dimension(self, current_path, current_view, dimension_name, dim_val):
        dim_type, json_type = self.get_dimension_types(dim_val)
        self.ops += 1
        dimension_name_path = dimension_name
        path_elements = filter(lambda _: "VALUE" not in _, current_path.split(":"))
        path_elements = list(path_elements)
        path_elements.reverse()
        prev_dim = ""
        pe_to_dim_name = []
        for i, pe in enumerate(path_elements):
            prev_dim += pe + "_"
            pe_to_dim_name.append(pe)
            if i > self.maximum_naming_levels:
                break
        # create nice description based on path and dimension name
        separate_words = re.sub('(?!^)([A-Z][a-z]+)', r' \1', dimension_name).split()
        separate_words = map(lambda _: _.capitalize(), pe_to_dim_name + separate_words)
        nice_description = ' '.join(separate_words)
        current_path = current_path + (":" if current_path else "") + dimension_name_path

        dimension_name = prev_dim + dimension_name
        new_dimension = lt.dimension_str_template.format(__dimension_name=dimension_name,
                                                         __desc=nice_description,
                                                         __path=current_path,
                                                         looker_type=dim_type, json_type=json_type)
        self.views_dimensions_expr[current_view].append(new_dimension)

    def get_dimension_types(self, dim_val):
        json_type = "string"
        if dim_val is None or (type(dim_val) == list and len(dim_val) == 0):
            dim_type = ""
        elif type(dim_val) == str:
            dim_type = "string"
            json_type = "string"
            if is_str_timestamp(dim_val):
                dim_type = "date_time"
        elif type(dim_val) == bool:
            dim_type = "yesno"
            json_type = "boolean"
        elif type(dim_val) == int:
            dim_type = "number"
            json_type = "number"
        else:
            dim_type = "date"
        return dim_type, json_type

    def process_jsons(self, json_string_list):
        """

        :param json_string_list: List with python dicts
        :return:
        """
        for json_file in json_string_list:
            with open(json_file) as f_in:
                json_obj = json.load(f_in)
            self.collect_all_paths(current_dict=json_obj)
            self.create_view_file()
            self.create_explore_file()

    def create_view_file(self):
        views_out_file = open("output.view.ml", "w")
        for view, dimensions in self.views_dimensions_expr.items():
            source_table = ""
            if view == "base":
                source_table = """\n\tsql_table_name: PROD_BETA.orders ;;"""

            views_out_file.write(lt.view_start_str_template.format(name=view, base_table=source_table))
            for dim in dimensions:
                views_out_file.write(dim)
            views_out_file.write(lt.view_end_str)
        views_out_file.close()

    def create_explore_file(self):
        explore_out_file = open("explore.lkml", "w")
        explore_out_file.write(
            lt.explore_start_str_template.format(explore_name="base", base_view_alias="base", base_view="base",
                                                 description="Base explore", label="Base explore"))
        for explore_join in self.explore_joins:
            explore_out_file.write(explore_join)
        explore_out_file.write(lt.explore_end)
        explore_out_file.close()
