#!/usr/bin/env bash
python3 main.py